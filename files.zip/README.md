# ACI · Terminal de Análisis Cuantitativo

Terminal web de análisis financiero cuantitativo. Corre 100% en el browser — sin backend, sin instalación. Los datos vienen de Yahoo Finance en tiempo real.

## Demo

Abrí `index.html` en tu browser, o desplegalo en GitHub Pages.

## Módulos disponibles (32)

### Correlación
| # | Módulo | Descripción |
|---|--------|-------------|
| 01 | Matriz de Covarianza | Varianzas y covarianzas diarias y anualizadas |
| 02 | Correlación de Pearson | Heatmap de correlaciones lineales entre activos |
| 03 | Pearson vs No Lineal | Comparación Pearson / Spearman / Kendall |
| 04 | Distancia de Frobenius | Estabilidad temporal de la matriz de correlaciones |

### Indicadores Técnicos
| # | Módulo | Descripción |
|---|--------|-------------|
| 05 | MACD | EMA12−EMA26, señal EMA9, histograma |
| 06 | Estocástico | %K/%D, zonas sobrecompra/sobreventa |
| 07 | CCI | Commodity Channel Index (período 20) |
| 08 | Exponente de Hurst | Rolling 100d — tendencia vs reversión vs aleatorio |
| 09 | Ondas de Elliott | Detección de picos y valles (Savitzky-Golay) |
| 22 | RSI | Relative Strength Index — suavizado de Wilder |
| 23 | Bollinger Bands | MA20 ± 2σ rolling |
| 24 | Keltner Channels | Fórmula original Chester Keltner 1960 |
| 25 | On Balance Volume | OBV vectorizado (np.sign equivalente) |
| 26 | Money Flow Index | RSI ponderado por volumen |
| 27 | Impulso / Momentum | close − close.shift(10) |
| 28 | Oscilador de Aroon | Up/Down/Oscilador (Chande, n=25) |
| 29 | Oscilador de Acumulación | OAD de Williams (0−100) |
| 30 | Bandas de Autoregresión | Regresión lineal ± 2σ residuos |

### Value at Risk
| # | Módulo | Descripción |
|---|--------|-------------|
| 10 | VaR Paramétrico | Fórmula cerrada Normal, configurable |
| 11 | VaR Histórico | Distribución empírica de retornos reales |
| 12 | VaR Monte Carlo | 10.000 simulaciones multivariadas |
| 13 | VaR Comparación | Los 3 métodos lado a lado |

### Performance Attribution
| # | Módulo | Descripción |
|---|--------|-------------|
| 14 | Brinson-Hood-Beebower | Asignación + Selección + Interacción |
| 15 | Brinson-Fachler | 2 efectos (sin interacción explícita) |

### Portafolio / CAPM
| # | Módulo | Descripción |
|---|--------|-------------|
| 16 | CAPM y SML | Beta, alfa, Security Market Line |
| 17 | Frontera Eficiente MC | 3.000 portafolios aleatorios |
| 18 | CML Simulación | Capital Market Line vía simulación |
| 19 | CML Optimización | CML con mayor densidad de iteraciones |
| 20 | Frontera Upside | Markowitz con retornos esperados propios |
| 21 | Upside Cap 20% | Frontera upside con restricción por activo |

### Fundamentals
| # | Módulo | Descripción |
|---|--------|-------------|
| 31 | Estados Contables | Balance, P&L, Cash Flow vía FMP API |
| 32 | Portfolio Ratios | P/E, P/B, P/CF, EV/EBITDA vía FMP API |

## Configuración

### API Keys necesarias

**Anthropic (obligatorio)** — para las interpretaciones de Claude:
1. Entrá a [console.anthropic.com](https://console.anthropic.com)
2. Creá una API key
3. Pegala en el banner amarillo al abrir la app

**Financial Modeling Prep (solo módulos 31 y 32)** — para estados contables y ratios:
1. Registrate gratis en [financialmodelingprep.com](https://financialmodelingprep.com)
2. Copiá tu API key gratuita
3. Pegala en el panel de Estados Contables o Portfolio Ratios

> Ambas keys se guardan solo en `sessionStorage` de tu browser — nunca salen de tu máquina.

### Datos de mercado

Los módulos 01-30 descargan datos reales de **Yahoo Finance** automáticamente. Sin key, sin registro. La app intenta 4 rutas en orden:
1. Yahoo Finance directo
2. `api.allorigins.win` (proxy CORS)
3. `corsproxy.io` (proxy alternativo)  
4. Yahoo Finance query2

### Tickers soportados

Cualquier ticker válido en Yahoo Finance:
- Acciones US: `AAPL`, `MSFT`, `GOOGL`, `NVDA`
- ADRs argentinos: `GGAL`, `YPF`, `BMA`, `BBAR`, `PAM`
- ETFs: `SPY`, `QQQ`, `GLD`
- Crypto: `BTC-USD`, `ETH-USD`
- Índices: `^GSPC`, `^MERV`

## Deploy en GitHub Pages

1. Creá un repo nuevo en GitHub (puede ser privado o público)
2. Subí `index.html` a la raíz
3. En **Settings → Pages → Source**: seleccioná `main` branch, carpeta `/root`
4. Tu terminal queda en `https://tu-usuario.github.io/nombre-repo`

## Stack técnico

- HTML + CSS + JavaScript vanilla (sin frameworks)
- [Plotly.js](https://plotly.com/javascript/) para gráficos interactivos
- [Claude API](https://docs.anthropic.com) (`claude-sonnet-4-6`) para interpretaciones
- [Yahoo Finance v8](https://query1.finance.yahoo.com) para datos OHLCV
- [Financial Modeling Prep](https://financialmodelingprep.com) para fundamentals

## Estructura del proyecto

```
/
└── index.html      # App completa (todo en un archivo)
└── README.md       # Este archivo
```

---

*Desarrollado para la Maestría en Finanzas — ACI I*
